# NEXUS CLOUD OS 1.0 — Comece por aqui

## O que você recebeu

Este pacote prepara o NEXUS para abrir um **desktop Linux real na nuvem** dentro da janela do NEXUS. Ao iniciar uma sessão, o servidor cria um contêiner Linux novo com ambiente XFCE e Chromium. Ao desligar ou passar 15 minutos sem atividade, o servidor remove o contêiner e os dados temporários.

**Importante:** isto é um desktop Linux em contêiner, não uma VM KVM completa. Não inclui GPU dedicada, Windows, GTA V ou jogos de PC pesados. O sistema HTML sozinho não consegue fornecer processamento na nuvem: ele precisa de um servidor Linux ligado à internet.

## O que é necessário

- Um servidor VPS com Ubuntu Server 24.04 LTS, arquitetura x86-64.
- Recomendação inicial: 4 vCPU, 8 GB RAM e 25 GB SSD para uma sessão.
- IPv4 público e portas TCP 80 e 443 liberadas no firewall do provedor.
- Um domínio próprio, com dois registros DNS do tipo A apontando para o IP do servidor: `nexus.seudominio.com` e `desktop.seudominio.com`.
- Docker Engine, plugin Docker Compose, `iptables` e acesso administrativo ao servidor.

Como o usuário deste projeto é menor de idade, um responsável deve cuidar da contratação da VPS/domínio, pagamentos e dados de conta.

## Instalação em 5 etapas

### 1. Preparar o domínio

No painel DNS do domínio, crie dois registros A:

| Tipo | Nome | Valor |
|---|---|---|
| A | `nexus` | IP público da VPS |
| A | `desktop` | IP público da VPS |

Aguarde a atualização do DNS antes de tentar entrar no site. O Caddy obtém os certificados HTTPS automaticamente, mas precisa conseguir alcançar os dois nomes pela internet.

### 2. Instalar Docker no Ubuntu

Siga o guia oficial atualizado: <https://docs.docker.com/engine/install/ubuntu/>.

O pacote precisa do Docker Engine e do plugin Compose. O guia oficial do Compose está em <https://docs.docker.com/compose/install/linux/>. Depois, confirme que o comando `docker compose version` funciona e que o serviço Docker está ativo.

O instalador também exige `iptables` e a cadeia `DOCKER-USER` do Docker. Ele para em vez de iniciar o desktop se não conseguir ativar o filtro de rede.

### 3. Enviar o pacote para o servidor

Envie o arquivo `NEXUS-CLOUD-OS-1.0.zip` para a VPS por SFTP ou pelo gerenciador de arquivos do painel da VPS. Extraia o ZIP. A pasta `nexus-cloud-os` precisa conter `setup.sh`, `docker-compose.yml`, `Caddyfile`, `index.html` e as pastas `server`, `controller`, `desktop`, `proxy` e `scripts`.

### 4. Executar o instalador

Abra um terminal SSH no servidor, entre na pasta extraída e execute:

```bash
cd nexus-cloud-os
sudo ./setup.sh
```

O instalador vai pedir:

1. Domínio raiz (exemplo: `seudominio.com`, sem `https://`).
2. E-mail para o certificado HTTPS.
3. Nome de usuário do NEXUS.
4. Uma senha forte com pelo menos 14 caracteres.

Ele cria o arquivo `.env` com permissões restritas, gera o hash da senha e um token aleatório do controlador, constrói as imagens, inicia os serviços privados, instala o filtro de saída de rede e só então liga o gateway HTTPS público.

### 5. Entrar no NEXUS

Abra `https://nexus.seudominio.com` no navegador do celular ou computador e use o usuário e a senha configurados. Pressione **START COMPUTER** e abra **Cloud PC**. O Chromium remoto deve abrir dentro do desktop transmitido. Na primeira conexão, talvez seja necessário tocar em **Reconnect** depois de alguns segundos.

O navegador pode pedir o mesmo usuário e senha novamente ao abrir o desktop, porque o subdomínio `desktop` é uma origem HTTPS separada.

## Comandos úteis

Dentro da pasta do projeto no servidor:

```bash
# Ver os serviços
sudo docker compose ps

# Ver logs do NEXUS e do controlador
sudo docker compose logs -f nexus controller

# Ver logs do proxy e do HTTPS
sudo docker compose logs -f session-proxy caddy

# Conferir a proteção de rede
sudo systemctl status nexus-desktop-egress-guard

# Reaplicar a proteção após recriar a rede Docker
sudo systemctl restart nexus-desktop-egress-guard
```

Se você tiver executado `docker compose down` e for subir tudo novamente, faça nessa ordem para não abrir o desktop antes do filtro de rede:

```bash
sudo docker compose up -d nexus controller session-proxy
sudo systemctl restart nexus-desktop-egress-guard
sudo docker compose up -d caddy
```

Não exponha as portas 9000 (controlador) nem 3000/3001 (desktop) diretamente. Somente 80 e 443 devem ficar públicos.

## O que está realmente incluído

- Desktop XFCE Linux real remoto com Chromium.
- Streaming dentro da janela NEXUS por WebSocket/Selkies e proxy HTTPS.
- Criação e remoção de um contêiner por sessão.
- Perfil do Chromium, pasta `/config` e `/tmp` temporários.
- Encerramento manual e limpeza após 15 minutos sem heartbeat.
- Autenticação por senha no proxy HTTPS.
- Filtro de rede para impedir o desktop de iniciar conexões IPv4 para faixas privadas, loopback, link-local, endereços reservados e novas conexões ao host Docker.

## O que ainda não está incluído

- Uma VPS ou domínio pagos: precisam ser fornecidos por você/responsável.
- Uma VM completa QEMU/KVM; a sessão atual é um contêiner Linux que compartilha o kernel da VPS.
- GPU dedicada, Windows, GTA V ou jogos pesados.
- IA do NEXUS configurada com uma chave/API. O app não inventa respostas quando não existe provedor.
- Persistência de arquivos entre sessões. A limpeza temporária é intencional.

## Segurança importante

O controlador precisa acessar `/var/run/docker.sock` para criar e apagar os contêineres. Esse socket equivale a acesso administrativo ao host. Por isso o controlador não publica porta na internet, fica numa rede interna e usa token aleatório. Mesmo assim, mantenha o Ubuntu, Docker e imagens atualizados e não use esta instalação como serviço público multiusuário.

O desktop remoto inclui um terminal com privilégios dentro do contêiner. Ele não recebe o socket Docker nem portas publicadas no host, mas um erro grave no isolamento do contêiner ou no kernel ainda poderia afetar o servidor. O filtro de rede é uma camada adicional, não uma garantia absoluta.

## Testes de aceitação depois da instalação

1. Entrar no NEXUS e iniciar uma sessão.
2. Abrir **Cloud PC** e confirmar que o XFCE aparece dentro do NEXUS.
3. Abrir Chromium e visitar Google, YouTube e GitHub. Os sites devem ser renderizados pelo Chromium remoto, sem lançar apps Android.
4. Criar um arquivo de teste na pasta pessoal do desktop remoto.
5. Desligar o NEXUS e confirmar que `docker ps -a --filter label=nexus.managed=true` não mostra mais o contêiner da sessão.
6. Iniciar outra sessão e confirmar que o arquivo temporário da sessão anterior não existe.
7. Fechar a página e confirmar que o contêiner é removido após o tempo de inatividade.

Este ambiente de desenvolvimento não possui Docker nem uma VPS pública conectada. Portanto, o pacote foi validado por verificações estáticas, mas a inicialização real do contêiner, HTTPS público e streaming precisam ser testados na VPS seguindo a lista acima.
