#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

command -v python3 >/dev/null 2>&1 || { echo 'python3 is required' >&2; exit 1; }
python3 -m py_compile server/main.py controller/main.py
bash -n setup.sh scripts/apply-desktop-egress-guard.sh
sh -n desktop/nexus-chromium.sh

python3 - <<'PY'
from pathlib import Path
html = Path('index.html').read_text(encoding='utf-8')
assert '<!-- NEXUS_RUNTIME_CONFIG -->' in html
assert '/api/session/start' in html and '/api/session/end' in html and '/api/session/touch' in html
assert 'target="_blank"' not in html and "target='_blank'" not in html
assert 'window.open' not in html
script = html.split('<script>', 1)[1].split('</script>', 1)[0]
Path('/tmp/nexus-cloud-os-inline.js').write_text(script, encoding='utf-8')
compose = Path('docker-compose.yml').read_text(encoding='utf-8')
assert 'dockerfile: server/Dockerfile' in compose
assert 'NEXUS_ORIGIN: https://nexus.' in compose
assert 'SELKIES_FRAME_ANCESTORS' in Path('controller/main.py').read_text(encoding='utf-8')
print('HTML integration and Compose/controller configuration: PASS')
try:
    import yaml
    data = yaml.safe_load(compose)
    assert {'caddy', 'nexus', 'controller', 'session-proxy'} <= set(data['services'])
    assert data['services']['nexus']['build']['context'] == '.'
    print('Compose YAML parse: PASS')
except ImportError:
    print('Compose YAML parse: SKIPPED (PyYAML is not installed)')
PY

if command -v node >/dev/null 2>&1; then
  node --check /tmp/nexus-cloud-os-inline.js
  echo 'Frontend JavaScript syntax: PASS'
else
  echo 'Frontend JavaScript syntax: SKIPPED (Node.js is not installed)'
fi

echo 'Static verification completed. This does not replace building and testing containers on the target VPS.'
