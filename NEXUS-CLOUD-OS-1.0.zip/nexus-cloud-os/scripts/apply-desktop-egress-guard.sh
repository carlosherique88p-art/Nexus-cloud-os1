#!/usr/bin/env bash
set -euo pipefail

NETWORK_NAME="nexus-desktop-net"
EGRESS_CHAIN="NEXUS-DESKTOP-EGRESS"
HOST_CHAIN="NEXUS-DESKTOP-HOST"

if ! command -v iptables >/dev/null 2>&1; then
  echo "iptables is required for the NEXUS desktop egress guard." >&2
  exit 1
fi
if ! iptables -nL DOCKER-USER >/dev/null 2>&1; then
  echo "Docker's DOCKER-USER chain is unavailable. Use Docker's supported iptables firewall backend." >&2
  exit 1
fi

subnet=""
network_id=""
for attempt in $(seq 1 30); do
  subnet=$(docker network inspect "$NETWORK_NAME" --format '{{(index .IPAM.Config 0).Subnet}}' 2>/dev/null || true)
  network_id=$(docker network inspect "$NETWORK_NAME" --format '{{.Id}}' 2>/dev/null || true)
  [[ -n "$subnet" && -n "$network_id" ]] && break
  sleep 1
done
if [[ -z "$subnet" || -z "$network_id" ]]; then
  echo "Docker network $NETWORK_NAME was not found. Start the private Compose services first." >&2
  exit 1
fi

bridge=$(docker network inspect "$NETWORK_NAME" --format '{{index .Options "com.docker.network.bridge.name"}}' 2>/dev/null || true)
bridge=${bridge:-"br-${network_id:0:12}"}

# Filter packets forwarded out of the desktop bridge. This prevents a hostile
# website opened inside Chromium from reaching RFC1918, loopback, link-local,
# reserved and common cloud metadata endpoints through the container network.
iptables -N "$EGRESS_CHAIN" 2>/dev/null || true
iptables -F "$EGRESS_CHAIN"
iptables -A "$EGRESS_CHAIN" -m conntrack --ctstate ESTABLISHED,RELATED -j RETURN
iptables -A "$EGRESS_CHAIN" -m conntrack --ctstate INVALID -j DROP
for range in \
  0.0.0.0/8 \
  10.0.0.0/8 \
  100.64.0.0/10 \
  127.0.0.0/8 \
  169.254.0.0/16 \
  172.16.0.0/12 \
  192.0.0.0/24 \
  192.0.2.0/24 \
  192.88.99.0/24 \
  192.168.0.0/16 \
  198.18.0.0/15 \
  198.51.100.0/24 \
  203.0.113.0/24 \
  224.0.0.0/4 \
  240.0.0.0/4; do
  iptables -A "$EGRESS_CHAIN" -d "$range" -j DROP
done
iptables -A "$EGRESS_CHAIN" -j RETURN
iptables -C DOCKER-USER -s "$subnet" -j "$EGRESS_CHAIN" 2>/dev/null || iptables -I DOCKER-USER 1 -s "$subnet" -j "$EGRESS_CHAIN"

# Traffic addressed to the Docker host itself traverses INPUT rather than
# DOCKER-USER. Block new connections arriving from this bridge as well.
iptables -N "$HOST_CHAIN" 2>/dev/null || true
iptables -F "$HOST_CHAIN"
iptables -A "$HOST_CHAIN" -m conntrack --ctstate ESTABLISHED,RELATED -j RETURN
iptables -A "$HOST_CHAIN" -j DROP
iptables -C INPUT -i "$bridge" -s "$subnet" -j "$HOST_CHAIN" 2>/dev/null || iptables -I INPUT 1 -i "$bridge" -s "$subnet" -j "$HOST_CHAIN"

echo "NEXUS desktop egress guard active: subnet=$subnet bridge=$bridge. Public IPv4 internet remains available; private/reserved destinations and new connections to the Docker host are blocked."
