#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")"

if (( EUID != 0 )); then
  echo "Run this installer as root: sudo ./setup.sh" >&2
  exit 1
fi
for cmd in docker openssl iptables systemctl install; do
  if ! command -v "$cmd" >/dev/null 2>&1; then
    echo "Required command not found: $cmd" >&2
    exit 1
  fi
done
if ! docker compose version >/dev/null 2>&1; then
  echo "Docker Compose plugin is missing. Install the official Docker Compose plugin first." >&2
  exit 1
fi
if ! docker info >/dev/null 2>&1; then
  echo "Docker Engine is not running or this account cannot access it." >&2
  exit 1
fi
if ! systemctl is-active --quiet docker; then
  echo "Docker must be managed by the system Docker service for the egress guard." >&2
  exit 1
fi

read -r -p "Your root domain (example: example.com): " domain
if [[ ! "$domain" =~ ^([a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}$ ]]; then
  echo "Invalid domain. Enter a real domain without https:// or a path." >&2
  exit 1
fi
domain=${domain,,}
for host in "nexus.$domain" "desktop.$domain"; do
  if command -v getent >/dev/null 2>&1 && ! getent ahostsv4 "$host" >/dev/null 2>&1; then
    echo "WARNING: $host does not resolve yet. Point its DNS A record to this VPS before expecting HTTPS to work." >&2
  fi
done
read -r -p "ACME email for HTTPS certificates: " email
if [[ ! "$email" =~ ^[^@[:space:]]+@[^@[:space:]]+\.[^@[:space:]]+$ ]]; then
  echo "Invalid email address." >&2
  exit 1
fi
read -r -p "NEXUS login username [nexus]: " username
username=${username:-nexus}
if [[ ! "$username" =~ ^[a-zA-Z0-9._-]{3,32}$ ]]; then
  echo "Use 3-32 letters, numbers, dots, underscores or hyphens for the username." >&2
  exit 1
fi
read -r -s -p "Choose a strong password (at least 14 characters): " password
printf '\n'
if (( ${#password} < 14 )); then
  echo "Password must contain at least 14 characters." >&2
  exit 1
fi

printf "Generating a bcrypt password hash with the official Caddy image...\n"
# The official Caddy image already has ENTRYPOINT=caddy.
password_hash=$(docker run --rm caddy:2-alpine hash-password --plaintext "$password")
controller_token=$(openssl rand -hex 32)

umask 077
cat > .env <<ENV
NEXUS_DOMAIN=$domain
NEXUS_USER=$username
NEXUS_PASSWORD_HASH='$password_hash'
CONTROLLER_TOKEN=$controller_token
ACME_EMAIL=$email
ENV
unset password password_hash controller_token
chmod 600 .env

printf '\nBuilding the remote Linux desktop image...\n'
docker build --pull -t nexus-cloud-desktop:latest ./desktop
printf '\nBuilding NEXUS services...\n'
docker compose build --pull

# Start private services and create the Docker networks first. Caddy is
# deliberately started only after the outbound private-network guard is active.
printf '\nStarting private NEXUS services...\n'
docker compose up -d nexus controller session-proxy

printf '\nInstalling the desktop outbound network guard...\n'
install -m 0755 scripts/apply-desktop-egress-guard.sh /usr/local/sbin/nexus-desktop-egress-guard
install -m 0644 scripts/nexus-desktop-egress-guard.service /etc/systemd/system/nexus-desktop-egress-guard.service
systemctl daemon-reload
systemctl enable --now nexus-desktop-egress-guard.service

printf '\nStarting the public HTTPS gateway...\n'
docker compose up -d caddy

cat <<EOF

NEXUS services have been started.

NEXUS URL:   https://nexus.$domain
Desktop URL: https://desktop.$domain  (opened inside NEXUS)

Before using the service, make sure BOTH DNS A records point to this server's public IP:
  nexus.$domain
  desktop.$domain

Only ports 80 and 443 should be exposed publicly. Do not expose controller port 9000,
Docker's socket, or the Linux desktop's internal port 3000.

The desktop egress guard is installed as a systemd service. It blocks desktop containers
from initiating connections to private, loopback, link-local and metadata IPv4 ranges.

Check status with: docker compose ps
View logs with:    docker compose logs -f
Check firewall:    sudo systemctl status nexus-desktop-egress-guard
EOF
