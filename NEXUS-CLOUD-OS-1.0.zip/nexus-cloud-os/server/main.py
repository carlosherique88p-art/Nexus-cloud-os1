from __future__ import annotations

import asyncio
import hmac
import os
import re
import secrets
import time
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Any

import httpx
from fastapi import FastAPI, Header, HTTPException, Request
from fastapi.responses import HTMLResponse, JSONResponse

BASE_DIR = Path(__file__).resolve().parent
INDEX_FILE = BASE_DIR / "index.html"
CONTROLLER_URL = os.getenv("CONTROLLER_URL", "http://controller:9000").rstrip("/")
CONTROLLER_TOKEN = os.getenv("CONTROLLER_TOKEN", "")
NEXUS_DOMAIN = os.getenv("NEXUS_DOMAIN", "example.com").strip().lower()
IDLE_TIMEOUT_SECONDS = max(120, int(os.getenv("IDLE_TIMEOUT_SECONDS", "900")))
SESSION_ID_RE = re.compile(r"^[a-f0-9]{32}$")

active_session: str | None = None
last_activity: float = 0.0
state_lock = asyncio.Lock()
http: httpx.AsyncClient | None = None


def desktop_url() -> str:
    return f"https://desktop.{NEXUS_DOMAIN}/"


def runtime_config() -> str:
    # The only injected value is the deployment's fixed HTTPS desktop origin.
    # JSON encoding avoids accidental script injection through environment values.
    import json

    config = {"desktopUrl": desktop_url()}
    return "<script>window.NEXUS_RUNTIME_CONFIG=" + json.dumps(config) + ";</script>"


async def controller_request(method: str, path: str, *, json_body: dict[str, Any] | None = None) -> dict[str, Any]:
    if not CONTROLLER_TOKEN:
        raise HTTPException(status_code=503, detail="CONTROLLER_TOKEN is not configured")
    assert http is not None
    try:
        response = await http.request(
            method,
            f"{CONTROLLER_URL}{path}",
            json=json_body,
            headers={"X-Controller-Token": CONTROLLER_TOKEN},
        )
    except httpx.HTTPError as exc:
        raise HTTPException(status_code=503, detail=f"Session controller unavailable: {exc.__class__.__name__}") from exc
    if response.status_code >= 400:
        try:
            detail = response.json().get("detail", "Controller error")
        except Exception:
            detail = "Controller error"
        raise HTTPException(status_code=503, detail=str(detail)[:240])
    try:
        return response.json()
    except ValueError as exc:
        raise HTTPException(status_code=502, detail="Invalid response from session controller") from exc


async def destroy_session(session_id: str) -> bool:
    try:
        result = await controller_request("DELETE", f"/sessions/{session_id}")
        return bool(result.get("destroyed"))
    except HTTPException:
        return False


async def idle_sweeper() -> None:
    global active_session, last_activity
    while True:
        await asyncio.sleep(20)
        async with state_lock:
            if active_session and time.monotonic() - last_activity > IDLE_TIMEOUT_SECONDS:
                old = active_session
                # Do not hold the lock during a Docker stop request.
                active_session = None
                last_activity = 0.0
            else:
                old = None
        if old and not await destroy_session(old):
            async with state_lock:
                if active_session is None:
                    active_session = old
                    last_activity = time.monotonic()


@asynccontextmanager
async def lifespan(_: FastAPI):
    global http
    http = httpx.AsyncClient(timeout=httpx.Timeout(25.0, connect=5.0))
    task = asyncio.create_task(idle_sweeper())
    try:
        yield
    finally:
        task.cancel()
        try:
            await task
        except asyncio.CancelledError:
            pass
        await http.aclose()
        http = None


app = FastAPI(title="NEXUS CLOUD OS", version="1.0.0", lifespan=lifespan, docs_url=None, redoc_url=None, openapi_url=None)


@app.get("/", response_class=HTMLResponse)
async def index():
    try:
        html = INDEX_FILE.read_text(encoding="utf-8")
    except OSError as exc:
        raise HTTPException(status_code=500, detail="NEXUS interface file is missing") from exc
    html = html.replace("<!-- NEXUS_RUNTIME_CONFIG -->", runtime_config(), 1)
    return HTMLResponse(html, headers={"Cache-Control": "no-store", "X-Content-Type-Options": "nosniff"})


@app.get("/api/health")
async def health():
    try:
        result = await controller_request("GET", "/health")
        return {"ready": bool(result.get("ready")), "service": "nexus-api", "desktopImageReady": bool(result.get("desktopImageReady"))}
    except HTTPException as exc:
        return JSONResponse({"ready": False, "service": "nexus-api", "message": str(exc.detail)}, status_code=503)


def require_same_origin(request: Request) -> None:
    expected_origin = f"https://nexus.{NEXUS_DOMAIN}"
    origin = request.headers.get("origin")
    if not origin or origin.rstrip("/") != expected_origin:
        raise HTTPException(status_code=403, detail="A valid same-origin request is required")


@app.post("/api/session/start")
async def start_session(request: Request):
    global active_session, last_activity
    require_same_origin(request)

    async with state_lock:
        if active_session:
            # A page reload reconnects to the same container. If the controller restarted,
            # its recovery policy removed the old container and this call recreates it.
            await controller_request("POST", "/sessions", json_body={"sessionId": active_session})
            last_activity = time.monotonic()
            return {"sessionId": active_session, "reused": True}
        session_id = secrets.token_hex(16)
        await controller_request("POST", "/sessions", json_body={"sessionId": session_id})
        active_session = session_id
        last_activity = time.monotonic()
        return {"sessionId": session_id, "reused": False}


@app.post("/api/session/touch")
async def touch_session(request: Request, x_nexus_session: str | None = Header(default=None)):
    global last_activity
    require_same_origin(request)
    if not x_nexus_session or not SESSION_ID_RE.fullmatch(x_nexus_session):
        raise HTTPException(status_code=401, detail="Missing session token")
    async with state_lock:
        if not active_session or not hmac.compare_digest(active_session, x_nexus_session):
            raise HTTPException(status_code=403, detail="Session is no longer active")
        last_activity = time.monotonic()
    return {"ok": True}


@app.post("/api/session/end")
async def end_session(request: Request, x_nexus_session: str | None = Header(default=None)):
    global active_session, last_activity
    require_same_origin(request)
    if not x_nexus_session or not SESSION_ID_RE.fullmatch(x_nexus_session):
        raise HTTPException(status_code=401, detail="Missing session token")
    async with state_lock:
        if not active_session or not hmac.compare_digest(active_session, x_nexus_session):
            raise HTTPException(status_code=403, detail="Session is no longer active")
        old = active_session
        active_session = None
        last_activity = 0.0
    destroyed = await destroy_session(old)
    if not destroyed:
        async with state_lock:
            if active_session is None:
                active_session = old
                last_activity = time.monotonic()
        return JSONResponse({"destroyed": False, "message": "Shutdown requested, but the controller did not confirm deletion."}, status_code=503)
    return {"destroyed": True, "sessionId": old}


@app.get("/api/session/status")
async def session_status():
    return {"active": active_session is not None, "idleTimeoutSeconds": IDLE_TIMEOUT_SECONDS}
