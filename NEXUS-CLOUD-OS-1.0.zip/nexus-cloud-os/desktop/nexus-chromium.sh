#!/bin/sh
# Runs as the unprivileged Webtop desktop user inside the isolated container.
# No remote debugging port is opened; interaction is carried by the remote desktop stream.
set -eu

mkdir -p "$HOME/.config/chromium"
exec chromium \
  --no-first-run \
  --no-default-browser-check \
  --disable-infobars \
  --start-maximized \
  --user-data-dir="$HOME/.config/chromium" \
  https://www.google.com
