# NEXUS CLOUD OS 1.0 — Cloud Desktop Edition

NEXUS is now a web-based desktop shell connected to a **real remote Linux desktop**. A session creates a fresh LinuxServer Webtop container (the current `latest` tag is XFCE Alpine with Wayland support), streams it into a NEXUS window using Selkies, and removes that container when the user shuts down or the session expires.

This is a real remote Linux desktop **container**, not a QEMU/KVM virtual machine. It uses the host server's Linux kernel. It is suitable as the first Cloud PC milestone, not as a GPU gaming PC.

## What is real and what is still local

| Feature | Status in this release |
|---|---|
| Remote Linux desktop | Real XFCE desktop in an isolated Docker container |
| Chromium | Real Chromium launched inside the remote Linux desktop |
| Website access | Real internet access from remote Chromium |
| Display and input | Browser-based remote desktop streaming, embedded in NEXUS |
| Per-session desktop | New container for each session; container removed on shutdown |
| User home and downloads | Stored in temporary `/config` and `/tmp` mounts; removed with the container |
| NEXUS Files / Notes / Terminal | Local, in-browser session tools; they are not the remote Linux filesystem or shell |
| NEXUS Monitor | Its CPU/RAM/network figures are explicitly simulated; use Linux tools inside Cloud PC for real system information |
| NEXUS AI | Not configured with an API provider in this package; no fake AI responses are generated |
| GPU passthrough / GTA V / Windows apps | Not included; requires a GPU-capable host, a VM or suitable container graphics stack, and a separate game-streaming setup |

The actual Linux desktop is opened by the **Cloud PC** or **Browser** icon. Chromium starts automatically in that remote desktop. Use Chromium's address bar inside the streamed desktop; the old HTML-only preview has been replaced so NEXUS does not silently launch Android applications.

## Architecture

- `caddy`: HTTPS certificates and username/password protection for both NEXUS and the remote desktop.
- `nexus`: FastAPI server that serves the NEXUS interface, provisions sessions, and enforces an inactivity timeout.
- `controller`: private session controller. It can only create/remove the fixed NEXUS desktop image with a fixed set of options.
- `session-proxy`: Nginx reverse proxy with Docker DNS refresh and WebSocket support. It forwards the desktop stream to the currently active container.
- `desktop`: created on demand by the controller from `nexus-cloud-desktop:latest`. It is never published directly to the internet. Selkies is configured to allow framing only by the NEXUS origin.

The desktop container receives no host ports, no Docker socket, and no privileged mode. The controller does mount the host Docker socket because it must create and destroy the desktop container. That socket is effectively host-administrator access: keep the controller private, do not publish its port, keep the VPS patched, and do not run untrusted application code in this deployment.

## Server requirements

This package cannot create cloud hardware by itself. You need a Linux server with a public IPv4 address and Docker Engine + Docker Compose plugin.

Suggested starting point for one user:

- Ubuntu Server 24.04 LTS, x86-64.
- 4 vCPU and 8 GB RAM recommended for the host and one desktop session.
- At least 25 GB SSD storage for images and service data.
- A domain you control, with DNS A records for `nexus.yourdomain.tld` and `desktop.yourdomain.tld` pointing to the server.
- Inbound TCP 80 and 443; UDP 443 is optional but useful for HTTP/3.

The desktop itself has a 4 GB memory limit (swap capped at the same amount), 2 CPU limit and 512-process limit. The host needs extra memory for NEXUS, Caddy, Nginx, Docker and the operating system. If the host is smaller, reduce the desktop limits in `controller/main.py` only after understanding the performance trade-off.

**This package does not include a paid server, domain, API keys, or GPU.** A free static hosting site cannot run this architecture. If a VPS or domain must be purchased, a parent/guardian should handle the account and payment.

## Deploy on the Linux server

1. Point these two DNS A records to the VPS public IP:
   - `nexus.yourdomain.tld`
   - `desktop.yourdomain.tld`
2. Install Docker Engine and the Docker Compose plugin using Docker's official instructions: <https://docs.docker.com/engine/install/ubuntu/> and <https://docs.docker.com/compose/install/linux/>.
3. Copy this entire project folder to the server. Do not upload `.env` to GitHub or share it publicly.
4. Confirm that the Docker Engine uses its supported iptables-compatible firewall backend and exposes the `DOCKER-USER` chain. The setup script installs an outbound filter for the desktop network, which blocks private, loopback, link-local and cloud-metadata IPv4 destinations while leaving public websites reachable. Docker documents the `DOCKER-USER` chain and firewall backend requirements in its firewall guide.
5. Open a terminal in the project folder and run:

   ```bash
   sudo ./setup.sh
   ```

6. Enter the root domain (for example `yourdomain.tld`), certificate email, username and strong password. The script generates a bcrypt hash and a private controller token, builds the desktop image, starts private services, installs/enables the network guard, and only then starts the public HTTPS gateway.
7. Open `https://nexus.yourdomain.tld` and sign in. The same credentials protect the embedded desktop. The browser may ask for the credentials a second time on the `desktop` subdomain because it is a separate HTTPS origin.
8. Press **START COMPUTER**, then open **Cloud PC**. The first desktop startup can take a little while; use **Reconnect** if the desktop frame appears before the remote desktop service is ready.

## Useful commands

```bash
# Service status
docker compose ps

# NEXUS and controller logs
docker compose logs -f nexus controller

# HTTPS proxy logs
docker compose logs -f caddy session-proxy

# Stop the public services
docker compose down

# Rebuild after editing the desktop image or recreating the Docker networks
sudo ./setup.sh
```

`docker compose down` removes the application services, but it does not remove named Caddy certificate volumes. Do not run `docker compose down -v` unless you intentionally want to delete those certificate/config volumes too.

## Session lifecycle and data deletion

- One private desktop session is allowed per deployment.
- NEXUS sends a heartbeat while its page is open.
- If the page disappears, the server destroys the session after 15 minutes without a heartbeat.
- Pressing Shut down calls the controller to stop and remove the desktop container.
- The user's home folder and `/tmp` are mounted as temporary filesystems; removing the container discards those files and the container's writable layer.
- A controller restart intentionally removes old session containers. The next NEXUS session starts from the clean desktop image.

Do not store important files in this temporary Cloud PC. Copy them somewhere safe before shutting down.

## Security notes

- The only publicly published ports are 80 and 443.
- The setup installs systemd-managed iptables rules for the desktop Docker bridge. They block new IPv4 connections from the desktop to private, loopback, link-local, reserved and metadata address ranges, and block new desktop-to-host connections. The rules allow replies to established connections and public internet browsing. The installer stops if it cannot install this guard.
- The controller API is private to the Docker app network and protected by a random token.
- The controller has access to `/var/run/docker.sock`; compromise of this controller can compromise the VPS. Keep the deployment single-user and updated.
- The remote desktop is protected by Caddy Basic Authentication over HTTPS. Use a long, unique password.
- The desktop has no direct host ports and is not run in privileged mode.
- Websites are untrusted. Do not enter payment details or sensitive information into unknown websites.
- This is not a multi-user service. Do not give other people your NEXUS credentials.

## Limitations that are not being hidden

- This is an isolated Linux **container desktop**, not a KVM virtual machine. It shares the host kernel.
- The remote desktop image uses software/host-available rendering by default. No GPU is passed through in this release.
- High-end PC games such as GTA V are not expected to run. A gaming cloud PC needs an appropriate GPU host, compatible graphics drivers, a game-capable VM/container architecture, and a low-latency streaming pipeline.
- Windows `.exe` applications do not run natively in this Alpine Linux desktop.
- The NEXUS outer Files app, Terminal app, Notes and Monitor are still local shell utilities/simulations. Use the file manager and terminal inside the Cloud PC for real remote Linux files and commands.
- NEXUS AI has no provider credentials or server-side AI API configured. The interface reports this rather than pretending an AI is connected.
- Some websites may not support remote playback due to DRM, codecs, geolocation, authentication, or anti-bot restrictions.

## Verification checklist

After deployment, test these items manually:

1. Sign in to `https://nexus.yourdomain.tld`.
2. Start a Cloud PC session.
3. Open Cloud PC. Confirm an XFCE Linux desktop appears inside the NEXUS window.
4. Open Chromium in the remote desktop and visit Google, YouTube and GitHub. Confirm they render in the remote desktop and no Android app or external Chrome is launched.
5. Create a temporary file in the remote desktop's home folder.
6. Shut down NEXUS. Check controller logs and confirm the `nexus-desktop-...` container is removed (`docker ps -a --filter label=nexus.managed=true`).
7. Start a new session. Confirm a new clean desktop container appears and the temporary file from the previous session is gone.
8. Close the NEXUS tab without shutting down. Confirm the idle cleanup removes the session after the timeout.

This environment did not have Docker installed, so this package's containers could not be started or end-to-end tested here. The source code and frontend syntax were checked separately; the above runtime checklist must be completed on the target Linux server.

## Official technology references

- LinuxServer Webtop documentation: <https://docs.linuxserver.io/images/docker-webtop/>
- LinuxServer Selkies configuration (including `SELKIES_FRAME_ANCESTORS`): <https://docs.linuxserver.io/selkies/user-guide/configuration/>
- LinuxServer Selkies reverse proxy guide: <https://docs.linuxserver.io/selkies/user-guide/reverse-proxy/>
- LinuxServer Webtop image source (the current XFCE build includes Chromium, Thunar, Mousepad and XFCE components): <https://github.com/linuxserver/docker-webtop/blob/master/Dockerfile>
- Docker Engine installation: <https://docs.docker.com/engine/install/>
- Docker Compose installation: <https://docs.docker.com/compose/install/>
- Caddy automatic HTTPS: <https://caddyserver.com/docs/automatic-https>
