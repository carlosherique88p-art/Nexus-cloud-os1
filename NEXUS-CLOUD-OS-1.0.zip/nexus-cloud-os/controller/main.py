from __future__ import annotations

import hmac
import os
import re
import threading
from typing import Any

import docker
from docker.errors import APIError, ImageNotFound, NotFound
from fastapi import FastAPI, Header, HTTPException
from pydantic import BaseModel, Field

TOKEN = os.getenv("CONTROLLER_TOKEN", "")
IMAGE = os.getenv("DESKTOP_IMAGE", "nexus-cloud-desktop:latest")
NETWORK_NAME = os.getenv("DOCKER_NETWORK", "nexus-desktop-net")
TZ = os.getenv("TZ", "America/Fortaleza")
NEXUS_ORIGIN = os.getenv("NEXUS_ORIGIN", "")
SESSION_RE = re.compile(r"^[a-f0-9]{32}$")
lock = threading.RLock()
client: docker.DockerClient | None = None

app = FastAPI(title="NEXUS Session Controller", docs_url=None, redoc_url=None, openapi_url=None)


class StartRequest(BaseModel):
    sessionId: str = Field(pattern=r"^[a-f0-9]{32}$")


def authorize(token: str | None) -> None:
    if not TOKEN or not token or not hmac.compare_digest(TOKEN, token):
        raise HTTPException(status_code=401, detail="Unauthorized controller request")


def docker_client() -> docker.DockerClient:
    global client
    if client is None:
        try:
            client = docker.from_env(timeout=20)
            client.ping()
        except Exception as exc:
            raise HTTPException(status_code=503, detail=f"Docker daemon unavailable: {exc.__class__.__name__}") from exc
    return client


def get_session_container(session_id: str):
    if not SESSION_RE.fullmatch(session_id):
        raise HTTPException(status_code=400, detail="Invalid session id")
    name = f"nexus-desktop-{session_id[:12]}"
    try:
        container = docker_client().containers.get(name)
    except NotFound:
        return None
    if container.labels.get("nexus.managed") != "true" or container.labels.get("nexus.session_id") != session_id:
        raise HTTPException(status_code=403, detail="Container ownership check failed")
    return container


@app.on_event("startup")
def cleanup_orphaned_sessions() -> None:
    # A controller restart invalidates all old ephemeral desktop containers.
    if not TOKEN:
        return
    try:
        d = docker_client()
        for container in d.containers.list(all=True, filters={"label": "nexus.managed=true"}):
            try:
                container.remove(force=True)
            except APIError:
                pass
    except Exception:
        # /health reports the actual failure; startup should still complete for diagnostics.
        pass


@app.get("/health")
def health(x_controller_token: str | None = Header(default=None)) -> dict[str, Any]:
    authorize(x_controller_token)
    d = docker_client()
    try:
        d.images.get(IMAGE)
        image_ready = True
    except ImageNotFound:
        image_ready = False
    try:
        d.networks.get(NETWORK_NAME)
        network_ready = True
    except NotFound:
        network_ready = False
    return {"ready": image_ready and network_ready, "desktopImageReady": image_ready, "desktopNetworkReady": network_ready}


@app.post("/sessions")
def create_session(payload: StartRequest, x_controller_token: str | None = Header(default=None)) -> dict[str, Any]:
    authorize(x_controller_token)
    with lock:
        d = docker_client()
        try:
            image = d.images.get(IMAGE)
        except ImageNotFound as exc:
            raise HTTPException(status_code=503, detail=f"Desktop image {IMAGE} is not built. Run setup.sh again.") from exc
        try:
            network = d.networks.get(NETWORK_NAME)
        except NotFound as exc:
            raise HTTPException(status_code=503, detail=f"Docker network {NETWORK_NAME} is missing. Run docker compose up.") from exc

        existing = get_session_container(payload.sessionId)
        if existing:
            if existing.status != "running":
                existing.start()
            return {"sessionId": payload.sessionId, "container": existing.name, "reused": True}

        # This is a one-user deployment: remove any stale desktop before creating a new one.
        for old in d.containers.list(all=True, filters={"label": "nexus.managed=true"}):
            try:
                old.remove(force=True)
            except APIError:
                pass

        name = f"nexus-desktop-{payload.sessionId[:12]}"
        endpoint = d.api.create_endpoint_config(aliases=["nexus-desktop"])
        network_config = d.api.create_networking_config({NETWORK_NAME: endpoint})
        try:
            container = d.containers.create(
                image=IMAGE,
                name=name,
                hostname="nexus-desktop",
                detach=True,
                environment={
                    "PUID": "1000",
                    "PGID": "1000",
                    "TZ": TZ,
                    "TITLE": "NEXUS CLOUD PC",
                    "SELKIES_FRAME_ANCESTORS": NEXUS_ORIGIN,
                },
                shm_size="1g",
                mem_limit="4g",
                memswap_limit="4g",
                nano_cpus=2_000_000_000,
                pids_limit=512,
                tmpfs={
                    "/config": "rw,nosuid,nodev,size=2g,mode=1777",
                    "/tmp": "rw,nosuid,nodev,size=512m,mode=1777",
                },
                labels={
                    "nexus.managed": "true",
                    "nexus.session_id": payload.sessionId,
                },
                networking_config=network_config,
            )
            container.start()
        except APIError as exc:
            raise HTTPException(status_code=503, detail=f"Could not create Linux desktop: {exc.explanation or exc.__class__.__name__}") from exc
        return {"sessionId": payload.sessionId, "container": name, "reused": False, "image": image.tags[0] if image.tags else IMAGE}


@app.delete("/sessions/{session_id}")
def delete_session(session_id: str, x_controller_token: str | None = Header(default=None)) -> dict[str, Any]:
    authorize(x_controller_token)
    with lock:
        container = get_session_container(session_id)
        if not container:
            return {"destroyed": True, "alreadyAbsent": True}
        try:
            container.remove(force=True, v=True)
        except APIError as exc:
            raise HTTPException(status_code=503, detail=f"Could not remove desktop container: {exc.explanation or exc.__class__.__name__}") from exc
        return {"destroyed": True, "container": container.name}
